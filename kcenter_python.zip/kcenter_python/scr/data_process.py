import numpy as np
import pandas as pd
from sklearn.metrics.cluster import adjusted_rand_score
from sklearn.metrics import mutual_info_score

def data_preprocess(dataname, datapackage="datasets", path=None, missingchar=None, header=False, types=float):
    if path is None:
        data = pd.DataFrame(eval(f"datasets.{dataname}()"))
    elif missingchar is None:
        data = pd.read_csv(path + dataname, header=None if not header else 0)
    else:
        data = pd.read_csv(path + dataname, header=None if not header else 0, na_values=missingchar)
        data = data.dropna()
    
    if dataname == "iris":
        return data.iloc[:, :-1].to_numpy().T
    else:
        return data.iloc[:, :].to_numpy().T

def update_centers(X, assign, k):
    d, n = X.shape
    centers = np.zeros((d, k))
    wcounts = np.zeros(k)

    for j in range(n):
        cj = assign[j]
        for i in range(d):
            centers[i, cj] += X[i, j]
        wcounts[cj] += 1

    for j in range(k):
        cj = wcounts[j]
        centers[:, j] /= cj

    return centers

def get_center_cost(X, assign, k):
    d, n = X.shape
    centers = np.zeros((d, k))
    cost = 0

    for i in range(k):
        ci = X[:, assign == i]
        centers[:, i] = np.mean(ci, axis=1)
        cost += np.sum(np.sum((ci[:, j] - centers[:, i]) ** 2 for j in range(ci.shape[1])))

    return centers, cost

def plotResult(result, dataname):
    initLB = result[2][4] - 25
    initUB = result[2][5] + 25
    result[1][4:5] = [initLB, initUB]
    pRlt = np.delete(result, -1, axis=1)
    plt.plot(pRlt[0, :], pRlt[3:5, :].T, lw=2)
    gap = round(result[-1, -1], 5)
    plt.savefig(f"pic/{dataname}-ub_lb_crv{gap}.png")

def compute_nmi(z1, z2):
    n = len(z1)
    k1 = len(np.unique(z1))
    k2 = len(np.unique(z2))

    nk1 = np.zeros(k1)
    nk2 = np.zeros(k2)

    for idx, val in enumerate(np.unique(z1)):
        cluster_idx = np.where(z1 == val)[0]
        nk1[idx] = len(cluster_idx)

    for idx, val in enumerate(np.unique(z2)):
        cluster_idx = np.where(z2 == val)[0]
        nk2[idx] = len(cluster_idx)

    pk1 = nk1 / np.sum(nk1)
    pk2 = nk2 / np.sum(nk2)

    nk12 = np.zeros((k1, k2))
    for idx1, val1 in enumerate(np.unique(z1)):
        for idx2, val2 in enumerate(np.unique(z2)):
            cluster_idx1 = np.where(z1 == val1)[0]
            cluster_idx2 = np.where(z2 == val2)[0]
            common_idx12 = np.intersect1d(cluster_idx1, cluster_idx2)
            nk12[idx1, idx2] = len(common_idx12)

    pk12 = nk12 / n

    Hx = -np.sum(pk1 * np.log(pk1 + np.finfo(float).eps))
    Hy = -np.sum(pk2 * np.log(pk2 + np.finfo(float).eps))
    Hxy = -np.sum(pk12 * np.log(pk12 + np.finfo(float).eps))

    MI = Hx + Hy - Hxy
    return MI / (0.5 * (Hx + Hy))

def cluster_eval(z1, z2):
    K1 = len(np.unique(z1))
    K2 = len(np.unique(z2))

    nmi = compute_nmi(z1, z2)
    print("nmi:", nmi)

    vi = mutual_info_score(z1, z2)
    print("vi:", vi)

    ari = adjusted_rand_score(z1, z2)
    print("ari:", ari)

    return nmi, vi, ari