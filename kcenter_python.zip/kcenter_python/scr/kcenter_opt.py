import numpy as np
from scipy.spatial.distance import cdist
from scipy.optimize import minimize
from sklearn.metrics.pairwise import euclidean_distances

def obj_assign(centers, X):
    d, n = X.shape
    dmat = cdist(X.T, centers.T, metric='sqeuclidean')
    costs = np.zeros(n)
    for j in range(n):
        costs[j] = np.min(dmat[:, j])
    return np.max(costs)

def init_bound(X, k, lower=None, upper=None):
    lower_data = np.min(X, axis=1)
    upper_data = np.max(X, axis=1)
    lower_data = np.tile(lower_data[:, np.newaxis], k)
    upper_data = np.tile(upper_data[:, np.newaxis], k)

    if lower is None:
        lower = lower_data
        upper = upper_data
    else:
        lower = np.minimum(upper - 1e-4, np.maximum(lower, lower_data))
        upper = np.maximum(lower + 1e-4, np.minimum(upper, upper_data))
    return lower, upper

def max_dist(X, k, lower, upper):
    d, n = X.shape
    dmat_max = np.zeros((k, n))
    for j in range(n):
        for i in range(k):
            max_distance = 0
            for t in range(d):
                max_distance += max((X[t, j] - lower[t, i]) ** 2, (X[t, j] - upper[t, i]) ** 2)
            dmat_max[i, j] = max_distance
    return dmat_max

def sel_closest_centers(centers, X):
    d, k = centers.shape
    t_ctr = np.zeros((d, k))
    dmat = euclidean_distances(X.T, centers.T)
    for j in range(k):
        c, a = np.argmin(dmat[:, j]), np.argmin(dmat[:, j])
        t_ctr[:, j] = X[:, a]
    return t_ctr

def global_OPT_x(X, k, thread_flag, lower=None, upper=None, mute=False):
    d, n = X.shape
    lower, upper = init_bound(X, k, lower, upper)
    dmat_max = max_dist(X, k, lower, upper)
    inter_max = upper - lower

    def objective(centers):
        centers = centers.reshape((d, k))
        dmat = cdist(X.T, centers.T, metric='sqeuclidean')
        costs = np.min(dmat, axis=1)
        return -np.max(costs)

    def distance_constraint(centers):
        centers = centers.reshape((d, k))
        dmat = cdist(X.T, centers.T, metric='sqeuclidean')
        return dmat.flatten() - dmat_max.flatten()

    def b_constraint(b):
        b = b.reshape((k, n))
        return np.sum(b, axis=0) - 1

    def costs_constraint(costs):
        costs = costs.reshape(n)
        return costs - dmat.flatten()

    def lambda_constraint(lambda_):
        lambda_ = lambda_.reshape((k, n))
        return np.sum(lambda_, axis=1) - 1

    def center_constraint(center):
        center = center.reshape((d, k))
        return X.T - center.T - inter_max.flatten()[:, np.newaxis] * (1 - lambda_)

    def cost_constraint(cost):
        return cost - costs

    x0 = np.random.uniform(lower.flatten(), upper.flatten())
    bounds = [(lower.flatten()[i], upper.flatten()[i]) for i in range(d * k)]
    constraints = [{'type': 'ineq', 'fun': distance_constraint},
                   {'type': 'eq', 'fun': b_constraint},
                   {'type': 'ineq', 'fun': costs_constraint},
                   {'type': 'eq', 'fun': lambda_constraint},
                   {'type': 'eq', 'fun': center_constraint},
                   {'type': 'ineq', 'fun': cost_constraint}]
    
    if mute:
        options = {'disp': False}
    else:
        options = {'disp': True}
        
    result = minimize(objective, x0, method='SLSQP', bounds=bounds, constraints=constraints, options=options)
    centers = result.x.reshape((d, k))
    return centers

def global_OPT_L(X, k, thread_flag, lower=None, upper=None, mute=False):
    d, n = X.shape
    lower, upper = init_bound(X, k, lower, upper)
    dmat_max = max_dist(X, k, lower, upper)
    inter_max = upper - lower

    def objective(centers):
        centers = centers.reshape((d, k))
        dmat = cdist(X.T, centers.T, metric='sqeuclidean')
        costs = np.min(dmat, axis=1)
        return -np.max(costs)

    def distance_constraint(centers):
        centers = centers.reshape((d, k))
        dmat = cdist(X.T, centers.T, metric='sqeuclidean')
        return dmat.flatten() - dmat_max.flatten()

    def lambda_constraint(lambda_):
        lambda_ = lambda_.reshape((k, n))
        return np.sum(lambda_, axis=1) - 1

    def center_constraint(center):
        center = center.reshape((d, k))
        return X.T - center.T - inter_max.flatten()[:, np.newaxis] * (1 - lambda_)

    x0 = np.random.uniform(lower.flatten(), upper.flatten())
    bounds = [(lower.flatten()[i], upper.flatten()[i]) for i in range(d * k)]
    constraints = [{'type': 'ineq', 'fun': distance_constraint},
                   {'type': 'eq', 'fun': lambda_constraint},
                   {'type': 'eq', 'fun': center_constraint}]
    
    if mute:
        options = {'disp': False}
    else:
        options = {'disp': True}
        
    result = minimize(objective, x0, method='SLSQP', bounds=bounds, constraints=constraints, options=options)
    centers = result.x.reshape((d, k))
    return centers

def global_OPT_L4_CPX(X, k, thread_flag, lower=None, upper=None, mute=False):
    d, n = X.shape
    lower, upper = init_bound(X, k, lower, upper)
    dmat_max = max_dist(X, k, lower, upper)
    inter_max = upper - lower

    def objective(centers):
        centers = centers.reshape((d, k))
        dmat = cdist(X.T, centers.T, metric='sqeuclidean')
        costs = np.min(dmat, axis=1)
        return -np.max(costs)

    def distance_constraint(centers):
        centers = centers.reshape((d, k))
        dmat = cdist(X.T, centers.T, metric='sqeuclidean')
        return dmat.flatten() - dmat_max.flatten()

    def lambda_constraint(lambda_):
        lambda_ = lambda_.reshape((k, n))
        return np.sum(lambda_, axis=1) - 1

    def center_constraint(center):
        center = center.reshape((d, k))
        return X.T - center.T - inter_max.flatten()[:, np.newaxis] * (1 - lambda_)

    def max_cost_constraint(max_cost):
        return max_cost - obj_assign(centers, X)

    x0 = np.random.uniform(lower.flatten(), upper.flatten())
    bounds = [(lower.flatten()[i], upper.flatten()[i]) for i in range(d * k)]
    constraints = [{'type': 'ineq', 'fun': distance_constraint},
                   {'type': 'eq', 'fun': lambda_constraint},
                   {'type': 'eq', 'fun': center_constraint},
                   {'type': 'ineq', 'fun': max_cost_constraint}]
    
    if mute:
        options = {'disp': False}
    else:
        options = {'disp': True}
        
    result = minimize(objective, x0, method='SLSQP', bounds=bounds, constraints=constraints, options=options)
    centers = result.x.reshape((d, k))
    return centers