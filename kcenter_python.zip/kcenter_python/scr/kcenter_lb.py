import numpy as np
from scipy.spatial.distance import cdist
from numpy.random import choice
from kcenter_opt import fft_FBBT
from kcenter_ub import UB_sol

tol = 1e-6
mingap = 1e-3


def med(a, b, c):
    return a + b + c - max(a, b, c) - min(a, b, c)


def getGlobalLowerBound(nodeList):
    LB = 1e15
    nodeid = 1
    for idx, n in enumerate(nodeList):
        if n.LB < LB:
            LB = n.LB
            nodeid = idx
    return LB, nodeid


def sel_set(X, k, lower, upper):
    d, n = X.shape
    lwr = np.zeros((d, k))
    upr = np.zeros((d, k))

    all_num = np.zeros(k)
    for clst in range(k):
        set_ = []
        for s in range(n):
            if np.all(X[:, s] >= lower[:, clst]) and np.all(X[:, s] <= upper[:, clst]):
                set_.append(s)
                all_num[clst] += 1
                if all_num[clst] == 1:
                    lwr[:, clst] = X[:, s]
                    upr[:, clst] = X[:, s]
                elif all_num[clst] > 1:
                    for i in range(d):
                        if lwr[i, clst] > X[i, s]:
                            lwr[i, clst] = X[i, s]
                        if upr[i, clst] < X[i, s]:
                            upr[i, clst] = X[i, s]

        if all_num[clst] == 0:
            lwr = None
            upr = None
            break

    return lwr, upr


def getLB(V, k, d, lwr, upr):
    s_LB = np.zeros(k)
    all_mu = np.zeros((d, k))
    for clst in range(k):
        mu = med(lwr[:, clst], V, upr[:, clst])
        all_mu[:, clst] = mu
        s_LB[clst] = np.linalg.norm(mu - V, ord=2) ** 2
    best_LB = np.min(s_LB)
    return best_LB


def getLowerBound_analytic_basic(X, k, lower=None, upper=None):
    d, n = X.shape
    LB = np.zeros(n)
    for s in range(n):
        min_dist = getLB(X[:, s], k, d, lower, upper)
        LB[s] = min_dist
    return np.max(LB)


def getLowerBound_analytic_basic_FBBT(X, k, node, UB):
    d, n = X.shape
    lwr = node['lower'].copy()
    upr = node['upper'].copy()
    assign = node['assign']
    firstcheck = seedInAllCluster(assign, k)
    addSeed = False

    LB_s_array = np.zeros(n)
    all_LB_s_array = np.zeros((k, n))
    for s in range(n):
        LB_s_array[s], all_LB_s, LB_clst_s = getLB_FBBT(X[:, s], k, d, lwr, upr, assign[s])
        if assign[s] == 0:
            includ = all_LB_s <= UB
            if np.sum(includ) == 1:
                c = np.where(includ)[0][0] + 1
                assign[s] = c
                addSeed = True
            else:
                all_LB_s_array[:, s] = all_LB_s

    LB = max(np.max(LB_s_array), node['LB'])

    for s in range(n):
        if assign[s] != -1:
            UB_s, all_UB_s = getUB(X[:, s], k, d, lwr, upr, assign[s])
            if UB_s < LB:
                assign[s] = -1
            if assign[s] == 0:
                all_LB_s = all_LB_s_array[:, s]
                ind = np.argmin(all_LB_s)

                all_LB_s[ind] = 1e16
                if all_UB_s[ind] <= np.min(all_LB_s):
                    assign[s] = ind + 1

    if addSeed:
        secondcheck = seedInAllCluster(assign, k)
        if not firstcheck and secondcheck:
            seeds_ind = haveSeedInAllCluster(assign, k)
            fft_FBBT.expand_seeds(X, k, UB, seeds_ind)
            fft_FBBT.updateassign(assign, seeds_ind, k)
            print("expand in LB")

    return np.max(LB_s_array)


def NofAssignElements(assign):
    return len(assign) - np.sum(assign == 0) - np.sum(assign == -1)


def NofRmElements(assign):
    return np.sum(assign == -1)


def seedInAllCluster(assign, k):
    covered = np.zeros(k, dtype=bool)
    for i in assign:
        if i != 0 and i != -1:
            covered[i - 1] = True
    return np.sum(covered) == k


def haveSeedInAllCluster(assign, k):
    seeds_ind = [[] for _ in range(k)]
    for clst in range(1, k + 1):
        s = np.where(assign == clst)[0][0]
        seeds_ind[clst - 1].append(s)
    return seeds_ind


def getLB_FBBT(V, k, d, lwr, upr, clst_assigned):
    if clst_assigned == -1:
        return 0, None, -1
    elif clst_assigned == 0:
        all_LB = np.zeros(k)
        for clst in range(k):
            mu = med(lwr[:, clst], V, upr[:, clst])
            all_LB[clst] = np.linalg.norm(mu - V, ord=2) ** 2
        best_LB, ind = np.min(all_LB), np.argmin(all_LB)
        return best_LB, all_LB, ind + 1
    else:
        mu = med(lwr[:, clst_assigned - 1], V, upr[:, clst_assigned - 1])
        return np.linalg.norm(mu - V, ord=2) ** 2, None, clst_assigned


def getUB(V, k, d, lwr, upr, clst_assigned):
    if clst_assigned == -1:
        return 0, None
    elif clst_assigned == 0:
        all_UB = np.zeros(k)
        for clst in range(k):
            mu = UB_sol(lwr[:, clst], V, upr[:, clst])
            all_UB[clst] = np.linalg.norm(mu - V, ord=2) ** 2
        best_UB, _ = np.min(all_UB), None
        return best_UB, all_UB
    else:
        mu = UB_sol(lwr[:, clst_assigned - 1], V, upr[:, clst_assigned - 1])
        return np.linalg.norm(mu - V, ord=2) ** 2, None


def UB_sol(l, x, u):
    if np.abs(x - l) > np.abs(x - u):
        return l
    else:
        return u