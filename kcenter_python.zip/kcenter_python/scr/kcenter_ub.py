from kcenter_ub import *

import numpy as np
from scipy.spatial.distance import cdist
from numpy.random import choice

def max_dist(X1, X2):
    dist_matrix = cdist(X1.T, X2.T, metric='sqeuclidean')
    dist = np.min(dist_matrix, axis=1)
    c = np.max(dist)
    a = np.argmax(dist)
    return c, a
	

def fft(X, k):
    d, n = X.shape
    centers = np.zeros((d, k))
    z0 = np.random.randint(n)
    centers[:, 0] = X[:, z0]
    for j in range(1, k):
        dist = np.zeros(n)
        for i in range(n):
            dist[i] = np.min(cdist(X[:, i].reshape(-1, 1), centers[:, :j], metric='sqeuclidean'))
        a = np.argmax(dist)
        centers[:, j] = X[:, a]
    return centers

	
def fft_FBBT(X, k, lower, upper):
    d, n = X.shape
    centers = np.zeros((d, k))
    centers[:, 0] = (lower + upper) / 2
    for j in range(1, k + 1):
        dist = np.zeros(n)
        for i in range(n):
            dist[i] = np.min(cdist(X[:, i].reshape(-1, 1), centers[:, :j], metric='sqeuclidean'))
        a = np.argmax(dist)
        centers[:, j] = X[:, a]
    return centers[:, 1:k+1]


def getUpperBound(X, k, lower, upper, tol=0):
    UB = np.inf
    centers = None
    for tr in range(100):
        t_ctr = fft(X, k)
        t_UB = obj_assign(t_ctr, X)
        if tol <= UB - t_UB:
            UB = t_UB
            centers = t_ctr

    d, n = X.shape
    t_centers = (lower + upper) / 2
    t_ctr = sel_closest_centers(t_centers, X)
    for tr in range(100):
        t_UB = obj_assign(t_ctr, X)
        if tol <= UB - t_UB:
            UB = t_UB
            centers = t_ctr
        inds = choice(n, k, replace=False)
        t_ctr = X[:, inds]
    return centers, UB