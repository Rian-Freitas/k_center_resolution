import numpy as np
from copy import deepcopy
from Node import *


def SelectVarMaxRange(node):
    dif = node.upper - node.lower
    ind = np.unravel_index(np.argmax(dif), dif.shape)
    return ind[0], ind[1]


def branch(X, nodeList, bVarIdx, bVarIdy, bValue, node, node_LB, k, bt_method, symmtrc_breaking):
    d, n = X.shape
    lower = deepcopy(node.lower)
    upper = deepcopy(node.upper)
    upper[bVarIdx, bVarIdy] = bValue  # split from this variable at bValue
    if symmtrc_breaking == 1:
        for j in range(1, k):  # bound tightening avoid symmetric solution, for all feature too strong may eliminate other solution
            if upper[0, k-j] >= upper[0, k-j+1]:
                upper[0, k-j] = upper[0, k-j+1]

    if np.sum(lower <= upper) == d * k:
        left_node = Node(lower, upper, node.level + 1, node_LB, node.assign.copy(), node.center_cand.copy())
        nodeList.append(left_node)

    lower = deepcopy(node.lower)
    upper = deepcopy(node.upper)
    lower[bVarIdx, bVarIdy] = bValue
    if symmtrc_breaking == 1:
        for j in range(1, k):
            if lower[0, j] <= lower[0, j-1]:
                lower[0, j] = lower[0, j-1]

    if np.sum(lower <= upper) == d * k:
        right_node = Node(lower, upper, node.level + 1, node_LB, node.assign.copy(), node.center_cand.copy())
        nodeList.append(right_node)