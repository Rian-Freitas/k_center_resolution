import numpy as np
from scipy.spatial import distance_matrix
from scipy.spatial.distance import squareform, pdist
from Nodes import *
from kcenter_ub import *
from kcenter_opt import *
from kcenter_lb import *
from fbbt import *
from branch_ub import *

def branch_bound(X, k, bt_method="FBBT", symmtrc_breaking=1):
    # Scale the data
    x_max = np.max(X)
    tnsf_max = False
    if x_max > 20:
        tnsf_max = True
        X = X / (x_max * 0.05)

    d, n = X.shape
    lower, upper = kcenter_opt.init_bound(X, d, k)
    max_LB = 1e15
    centers, UB = kcenter_ub.getUpperBound(X, k, lower, upper, tol)
    root = Node(lower, upper, -1, -1e15, np.zeros(n, dtype=int), np.ones((n, k), dtype=bool))

    if bt_method == "FBBT":
        assign = np.zeros(n, dtype=int)
        findseeds = fbbt.select_seeds(X, k, UB, root.assign, 10)
        if not findseeds:
            symmtrc_breaking = 1
        else:
            oldboxSize = np.sum(upper - lower)
            oldUB = UB
            root_LB = -1e15
            stuck = 0
            for t in range(40):
                root.lower, root.upper = fbbt.fbbt_base(X, k, root, UB, 50)
                boxSize = np.sum(root.upper - root.lower)
                centers, UB = randomUB(X, root.lower, root.upper, UB, centers, 10)
                root_LB = kcenter_lb.getLowerBound_analytic_basic_FBBT(X, k, root, UB)
                root.LB = root_LB

                if boxSize / oldboxSize >= 0.99 and UB / oldUB >= 0.999:
                    stuck += 1
                else:
                    stuck = 0
                if stuck == 2:
                    break
                oldboxSize = boxSize
                oldUB = UB

                if (UB - root_LB) <= mingap * min(abs(root_LB), abs(UB)):
                    ctr_dist = distance_matrix(centers, centers)
                    min_ctr_dist = np.min(ctr_dist[np.nonzero(ctr_dist)])
                    rate = min_ctr_dist / UB

                    # Transfer back to the original value of the optimal value
                    if tnsf_max:
                        UB = UB * (x_max * 0.05) ** 2

                    return centers, UB, None

                remain = can_center_or_assign(root.assign, root.center_cand)
                if np.sum(remain) / n <= 0.8:
                    X = X[:, remain]
                    root.assign = root.assign[remain]
                    root.center_cand = root.center_cand[remain, :]
                    n = np.sum(remain)
    # Rest of the code...

    return centers, UB, calcInfo
	

def get_union_bound(nodeList):
    lower = None
    upper = None
    for idx, nd in enumerate(nodeList):
        if idx == 0:
            lower = np.copy(nd.lower)
            upper = np.copy(nd.upper)
        else:
            lower = np.minimum(lower, nd.lower)
            upper = np.maximum(upper, nd.upper)
    return lower, upper


def random_UB(X, lwr, upr, UB, centers, ntr=5):
    ctr = centers
    d, k = lwr.shape
    t_centers = (lwr + upr) / 2
    for tr in range(ntr):
        t_ctr = sel_closest_centers(t_centers, X)
        t_UB = obj_assign(t_ctr, X)
        if t_UB < UB:
            UB = t_UB
            ctr = t_ctr
        if tr != ntr-1:
            t_centers = np.random.rand(d, k) * (upr - lwr) + lwr
    return ctr, UB


def can_center_or_assign(assign, center_cand):
    n = len(assign)
    remain = np.ones(n, dtype=bool)
    for s in range(n):
        if assign[s] == -1:
            if np.sum(center_cand[s, :]) == 0:
                remain[s] = False
    return remain