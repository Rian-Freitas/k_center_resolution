from kcenter_ub import *

import numpy as np
from scipy.spatial.distance import cdist
from numpy.random import choice

def select_init_seeds(X, k, UB):
    d, n = X.shape
    init_seeds = np.zeros((d, k))
    init_seeds_ind = np.zeros(k, dtype=int)
    z = np.random.randint(n)
    init_seeds[:, 0] = X[:, z]
    init_seeds_ind[0] = z

    diffclst = 1
    for j in range(1, k):
        _, a = max_dist(X, init_seeds[:, :j])
        x = X[:, a]
        find_ = True
        for i in range(j - 1):
            if np.linalg.norm(x - init_seeds[:, i]) ** 2 < 4 * UB:
                find_ = False
                break
        if not find_:
            diffclst = 0
            break
        else:
            init_seeds[:, j] = x
            init_seeds_ind[j] = a
    return diffclst, init_seeds_ind


def select_seeds(X, k, UB, assign, n_trial=1):
    print("UB:   ", UB)
    d, n = X.shape
    iter_ = 0
    diffclst = 0
    init_seeds_ind = []
    while iter_ <= 100 and diffclst == 0:
        diffclst, init_seeds_ind = select_init_seeds(X, k, UB)
        iter_ += 1
    print("try", iter_, "times to select seeds")
    findseed = False
    if diffclst == 1:
        print("Find seeds successfully.")
        findseed = True
    else:
        print("Can not find seeds after 100 times.")

    seeds_ind = [[] for _ in range(k)]

    if diffclst == 1:
        for clst in range(k):
            seeds_ind[clst].append(init_seeds_ind[clst])
        expand_seeds(X, k, UB, seeds_ind, n_trial)
        updateassign(assign, seeds_ind, k)
    return findseed


def alreadyin(s, seeds_ind, k):
    exist = False
    for clst in range(k):
        if s in seeds_ind[clst]:
            exist = True
            break
    return exist


def updateassign(assign, seeds_ind, k):
    n = len(assign)
    for clst in range(k):
        for i in range(len(seeds_ind[clst])):
            ind = seeds_ind[clst][i]
            if assign[ind] != -1:
                assign[ind] = clst


def seedInAllCluster(seeds_ind):
    all_ = True
    for clst in range(len(seeds_ind)):
        if len(seeds_ind[clst]) == 0:
            all_ = False
            break
    return all_


def expand_seeds(X, k, UB, seeds_ind, n_trial=1):
    d, n = X.shape
    check = seedInAllCluster(seeds_ind)
    if not check:
        print("error! need to have at least one seed per cluster first!")

    inner_assign = np.zeros(n, dtype=int)
    for clst in range(k):
        for ind in seeds_ind[clst]:
            inner_assign[ind] = clst

    init_seeds = np.zeros((d, k))
    for clst in range(k):
        init_seeds[:, clst] = X[:, seeds_ind[clst][0]]

    for t in range(n_trial):
        for s in range(n):
            if inner_assign[s] == 0:
                includ = np.zeros(k, dtype=bool)
                x = X[:, s]
                for clst in range(k):
                    d_ = np.linalg.norm(x - init_seeds[:, clst]) ** 2
                    if d_ < 4 * UB:
                        includ[clst] = True
                if includ.sum() == 1:
                    c = np.nonzero(includ)[0][0]
                    seeds_ind[c].append(s)
                    inner_assign[s] = c

        for clst in range(k):
            ix = choice(len(seeds_ind[clst]))
            init_seeds[:, clst] = X[:, seeds_ind[clst][ix]]

    num = sum(len(seeds_ind[clst]) for clst in range(len(seeds_ind)))
    print("Expand #  seeds ", num)
    return seeds_ind


def divideclusternorm(X, UB, k, lower, upper, assign, center_cand, max_nseeds_c=20):
    d, n = X.shape
    lwr = lower.copy()
    upr = upper.copy()
    for clst in range(k):
        old_center_cand_clst = center_cand[:, clst]
        oldset = np.nonzero(old_center_cand_clst)[0]
        seeds_ind_c = [i for i in range(n) if assign[i] == clst]

        if len(seeds_ind_c) <= max_nseeds_c:
            nseed_c = len(seeds_ind_c)
            seeds_id = seeds_ind_c[0:nseed_c]
            seeds = X[:, seeds_id]
        else:
            seeds = fft_FBBT(X[:, seeds_ind_c], max_nseeds_c, lower[:, clst], upper[:, clst])
            # Alternatively, you can use the following code for smaller datasets:
            # if len(seeds_ind_c) >= 100000:
            #     inds = choice(seeds_ind_c, 100000, replace=False)
            #     seeds = fft(X[:, inds], max_nseeds_c, lower[:, clst], upper[:, clst])
            # else:
            #     seeds = fft(X[:, seeds_ind_c], max_nseeds_c, lower[:, clst], upper[:, clst])

        dmat = cdist(seeds.T, X[:, oldset].T, metric='sqeuclidean')

        num = 0
        center_cand[:, clst] = False
        for j in range(len(oldset)):
            s = oldset[j]
            if np.all(X[:, s] >= lower[:, clst]) and np.all(X[:, s] <= upper[:, clst]):
                if np.sum(dmat[:, j] > UB) == 0:
                    center_cand[s, clst] = True
                    num += 1
                    if num == 1:
                        lwr[:, clst] = X[:, s]
                        upr[:, clst] = X[:, s]
                    else:
                        for i in range(d):
                            if lwr[i, clst] > X[i, s]:
                                lwr[i, clst] = X[i, s]
                            if upr[i, clst] < X[i, s]:
                                upr[i, clst] = X[i, s]

        if num == 0:
            return None, None
        elif num == 1:
            s = np.nonzero(center_cand[:, clst])[0][0]
            if assign[s] == 0:
                assign[s] = clst

    return lwr, upr


def fbbt_base(X, k, node, UB, max_nseeds_c=20):
    d, n = X.shape
    assign = node['assign']
    center_cand = node['center_cand']

    lwr = node['lower'].copy()
    upr = node['upper'].copy()
    ra = np.sqrt(UB)

    for i in range(n):
        if assign[i] != 0 and assign[i] != -1:
            clst = assign[i]
            for j in range(d):
                if lwr[j, clst] < X[j, i] - ra:
                    lwr[j, clst] = X[j, i] - ra
                if upr[j, clst] > X[j, i] + ra:
                    upr[j, clst] = X[j, i] + ra
    for clst in range(k):
        if np.sum(lwr[:, clst] <= upr[:, clst]) != d:
            print("Delete this node")  # intersection is empty, delete this node
            return None, None

    lwr, upr = divideclusternorm(X, UB, k, lwr, upr, assign, center_cand, max_nseeds_c)
    if lwr is None and upr is None:
        print("Delete this node")  # intersection is empty, delete this node
        return None, None
    return lwr, upr