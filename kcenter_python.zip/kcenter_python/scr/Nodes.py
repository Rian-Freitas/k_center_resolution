class Node:
    def __init__(self):
        self.lower = None
        self.upper = None
        self.level = -1
        self.LB = -1e15
        self.assign = None
        self.center_cand = None

def printNodeList(nodeList):
    for node in nodeList:
        print([f"{x:.3f}" for x in node.lower])
        print([f"{x:.3f}" for x in node.upper])
        print(node.level)
        print([f"{x:.3f}" for x in node.LB])