import sys
from pathlib import Path

src_path = Path.cwd() / "src"
if str(src_path) not in sys.path:
    sys.path.append(str(src_path))

# Importar os módulos correspondentes
import kcenter_opt
import data_process
import kcenter_bb
import kcenter_lb
import Nodes
import fbbt
import branch
import kcenter_ub

"""
import sys
import os

# Adicionar o caminho "src/" ao sys.path
src_path = os.path.abspath("src/")
sys.path.append(src_path)

# Importar os módulos necessários
import kcenter_opt
import data_process
import kcenter_bb
import kcenter_lb
import Nodes
import fbbt
import branch
import kcenter_ub
"""