import numpy as np
import pandas as pd
import random
from sklearn.metrics.cluster import adjusted_rand_score
from sklearn.metrics import mutual_info_score
from scipy.linalg import qr
from numpy.linalg import LinAlgError

import sys
sys.path.append("src/")
from kcenter_opt import *

def data_preprocess(dataname, datapackage="datasets", path=None, missingchar=None, header=False, types=float):
    if path is None:
        data = pd.DataFrame(eval(f"datasets.{dataname}()"))
    elif missingchar is None:
        data = pd.read_csv(path + dataname, header=None if not header else 0)
    else:
        data = pd.read_csv(path + dataname, header=None if not header else 0, na_values=missingchar)
        data = data.dropna()
    
    if dataname == "iris":
        return data.iloc[:, :-1].to_numpy().T
    else:
        return data.iloc[:, :].to_numpy().T


dataname = ARGS[2]
if dataname == "iris":
    data = data_preprocess("iris") # read iris data from datasets package
else:
    if Sys.iswindows():
        data = data_preprocess(dataname, None, joinpath(__DIR__, "..\\data\\"), "NA") # read data in Windows
    else:
        data = data_preprocess(dataname, None, joinpath(__DIR__, "../data/"), "NA") # read data in Mac
print("data size:", data.shape)
print("data type:", type(data))

k = int(ARGS[1])
random.seed(123)

nlines = int(ARGS[3])

method = ARGS[4]
thread_flag = bool(ARGS[5])
if method == "LCP_CUT": # callback cut
    t_g, centers_g, objv_g, gap_g, cplex_cost, node_number = global_OPT_L4_CPX(data, k, nlines, thread_flag)
elif method == "LCP": 
    t_g, centers_g, objv_g, gap_g, cplex_cost, node_number = global_OPT_L(data, k, nlines, thread_flag)
elif method == "QCP":
    t_g, centers_g, objv_g, gap_g, cplex_cost, node_number = global_OPT_x(data, k, thread_flag)

print(f"{dataname}:\t{round(objv_g, 2)}\t{round(cplex_cost, 2)}\t{round(t_g, 2)}s\t{round(gap_g, 4)}%\t{node_number}")