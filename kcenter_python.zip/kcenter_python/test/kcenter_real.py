import sys
import numpy as np
from sklearn.datasets import load_iris
from pathlib import Path
import time
from timer_outputs import TimerOutputs

sys.path.append("src/")
from kcenter_opt import *
from kcenter_bb import *
from data_process import *

to = TimerOutputs()

@to.timeit("load data")
def load_data():
    args = sys.argv
    dataname = args[2]
    k = int(args[1])
    np.random.seed(123)
    if dataname == "iris":
        data = load_iris().data
    else:
        data_folder = Path.cwd() / "data"
        data_file = data_folder / (dataname + ".csv")
        data = np.genfromtxt(data_file, delimiter=',', missing_values="NA")
    print("data size:", data.shape)
    print("data type:", type(data))
    return data

@to.timeit("Total BB")
def total_bb(data):
    args = sys.argv
    flag_fbbt = bool(args[3])
    flag_SB = bool(args[4])
    if flag_fbbt:
        if not flag_SB:
            # closed form with FBBT, with/without symmetric breaking
            start_time = time.time()
            # Call the corresponding function for kcenter_bb.branch_bound(...)
            elapsed_time = time.time() - start_time
            centers, objv, calcInfo = None, None, None  # Replace None with actual values
            t_FBBT = elapsed_time
        else:
            print("wrong parameters")
    else:
        if flag_SB:
            # closed form with symmetric breaking, without FBBT
            start_time = time.time()
            # Call the corresponding function for kcenter_bb.branch_bound(...)
            elapsed_time = time.time() - start_time
            centers, objv, calcInfo = None, None, None  # Replace None with actual values
            t_sb = elapsed_time
        else:
            # closed without FBBT, without symmetric breaking
            start_time = time.time()
            # Call the corresponding function for kcenter_bb.branch_bound(...)
            elapsed_time = time.time() - start_time
            centers, objv, calcInfo = None, None, None  # Replace None with actual values
            t = elapsed_time

load_data()
total_bb(data)

to.show()
print()